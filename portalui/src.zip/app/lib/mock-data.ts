export interface Call {
  id: string;
  date: string;
  time: string;
  callerNumber: string;
  duration: string;
  outcome: 'answered' | 'missed' | 'transferred';
  hasRecording: boolean;
  hasTranscript: boolean;
  transcript?: string;
  recordingUrl?: string;
}

export const mockCalls: Call[] = [
  {
    id: '1',
    date: '2024-12-27',
    time: '2:45 PM',
    callerNumber: '+1 (555) 123-4567',
    duration: '3:24',
    outcome: 'answered',
    hasRecording: true,
    hasTranscript: true,
    transcript: 'Customer: Hi, I\'d like to make a reservation for tonight.\nAI: I\'d be happy to help you with that. For how many people?\nCustomer: Four people, please.\nAI: Great! What time would you prefer?\nCustomer: Around 7 PM if possible.\nAI: I have availability at 7:00 PM for a party of 4. Can I have your name please?\nCustomer: It\'s John Smith.\nAI: Perfect, John. Your reservation for 4 people at 7:00 PM tonight is confirmed. We look forward to seeing you!',
    recordingUrl: '#'
  },
  {
    id: '2',
    date: '2024-12-27',
    time: '1:30 PM',
    callerNumber: '+1 (555) 234-5678',
    duration: '1:12',
    outcome: 'answered',
    hasRecording: true,
    hasTranscript: true,
    transcript: 'Customer: What are your hours today?\nAI: We\'re open from 11:00 AM to 10:00 PM today. Is there anything else I can help you with?',
    recordingUrl: '#'
  },
  {
    id: '3',
    date: '2024-12-27',
    time: '12:15 PM',
    callerNumber: '+1 (555) 345-6789',
    duration: '0:00',
    outcome: 'missed',
    hasRecording: false,
    hasTranscript: false
  },
  {
    id: '4',
    date: '2024-12-27',
    time: '11:20 AM',
    callerNumber: '+1 (555) 456-7890',
    duration: '4:52',
    outcome: 'transferred',
    hasRecording: true,
    hasTranscript: true,
    transcript: 'Customer: I have a food allergy question about your menu.\nAI: I\'ll transfer you to our manager who can better assist you with that.',
    recordingUrl: '#'
  },
  {
    id: '5',
    date: '2024-12-26',
    time: '8:30 PM',
    callerNumber: '+1 (555) 567-8901',
    duration: '2:15',
    outcome: 'answered',
    hasRecording: true,
    hasTranscript: true,
    transcript: 'Customer: Do you take walk-ins?\nAI: Yes, we do accept walk-ins, though we recommend making a reservation to ensure we have a table available.',
    recordingUrl: '#'
  }
];

export const mockStats = {
  today: {
    totalCalls: 12,
    missedCalls: 2,
    avgDuration: '2:45',
    aiHandled: 9,
    transferred: 1
  },
  thisWeek: {
    callsPerDay: [
      { day: 'Mon', answered: 15, missed: 3 },
      { day: 'Tue', answered: 18, missed: 2 },
      { day: 'Wed', answered: 12, missed: 4 },
      { day: 'Thu', answered: 20, missed: 1 },
      { day: 'Fri', answered: 25, missed: 2 },
      { day: 'Sat', answered: 22, missed: 3 },
      { day: 'Sun', answered: 12, missed: 2 }
    ],
    peakHours: [
      { hour: '9AM', calls: 2 },
      { hour: '10AM', calls: 5 },
      { hour: '11AM', calls: 8 },
      { hour: '12PM', calls: 15 },
      { hour: '1PM', calls: 18 },
      { hour: '2PM', calls: 12 },
      { hour: '3PM', calls: 8 },
      { hour: '4PM', calls: 6 },
      { hour: '5PM', calls: 10 },
      { hour: '6PM', calls: 14 },
      { hour: '7PM', calls: 16 },
      { hour: '8PM', calls: 12 }
    ]
  }
};

export const mockSettings = {
  restaurantName: 'The Golden Fork',
  address: '123 Main Street, New York, NY 10001',
  timezone: 'America/New_York',
  publicPhone: '+1 (555) 123-4567',
  transferPhone: '+1 (555) 987-6543',
  features: {
    callsEnabled: true,
    recordingsEnabled: true,
    transcriptsEnabled: true
  }
};

export const mockBilling = {
  currentPlan: 'Professional',
  monthlyCost: 149,
  usage: {
    minutesUsed: 342,
    minutesIncluded: 500,
    callsHandled: 124
  },
  invoices: [
    { id: 'INV-001', date: 'December 1, 2024', amount: 149, status: 'paid' },
    { id: 'INV-002', date: 'November 1, 2024', amount: 149, status: 'paid' },
    { id: 'INV-003', date: 'October 1, 2024', amount: 149, status: 'paid' }
  ]
};

export const mockSMS = {
  enabled: true,
  messageTemplate: 'Thank you for calling The Golden Fork! Your reservation for {guests} on {date} at {time} is confirmed. Reply CANCEL to modify.',
  sentThisMonth: 86,
  status: 'active' as const
};
