import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Badge } from '../ui/badge';
import { Button } from '../ui/button';
import { Sheet, SheetContent, SheetHeader, SheetTitle } from '../ui/sheet';
import { Phone, Volume2, FileText } from 'lucide-react';
import { mockCalls, Call } from '../../lib/mock-data';

export function CallsPage() {
  const [selectedCall, setSelectedCall] = useState<Call | null>(null);

  const getOutcomeBadge = (outcome: string) => {
    const variants: Record<string, { variant: 'default' | 'secondary' | 'destructive'; label: string }> = {
      answered: { variant: 'default', label: 'Answered' },
      missed: { variant: 'destructive', label: 'Missed' },
      transferred: { variant: 'secondary', label: 'Transferred' }
    };
    const config = variants[outcome] || variants.answered;
    return <Badge variant={config.variant}>{config.label}</Badge>;
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-semibold text-gray-900">Calls</h1>
        <p className="text-gray-600 mt-1">View and manage all call activity</p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Call History</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-1">
            {/* Table Header */}
            <div className="grid grid-cols-6 gap-4 pb-3 border-b font-medium text-sm text-gray-600">
              <div className="col-span-2">Caller / Time</div>
              <div>Duration</div>
              <div>Outcome</div>
              <div>Recording</div>
              <div>Transcript</div>
            </div>

            {/* Table Rows */}
            {mockCalls.map((call) => (
              <div
                key={call.id}
                className="grid grid-cols-6 gap-4 py-4 border-b last:border-0 hover:bg-gray-50 cursor-pointer transition-colors"
                onClick={() => setSelectedCall(call)}
              >
                <div className="col-span-2">
                  <p className="font-medium text-gray-900">{call.callerNumber}</p>
                  <p className="text-sm text-gray-500">{call.date} at {call.time}</p>
                </div>
                <div className="flex items-center text-gray-700">{call.duration}</div>
                <div className="flex items-center">{getOutcomeBadge(call.outcome)}</div>
                <div className="flex items-center">
                  {call.hasRecording ? (
                    <Volume2 className="h-4 w-4 text-blue-600" />
                  ) : (
                    <span className="text-sm text-gray-400">—</span>
                  )}
                </div>
                <div className="flex items-center">
                  {call.hasTranscript ? (
                    <FileText className="h-4 w-4 text-green-600" />
                  ) : (
                    <span className="text-sm text-gray-400">—</span>
                  )}
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Call Details Drawer */}
      <Sheet open={!!selectedCall} onOpenChange={() => setSelectedCall(null)}>
        <SheetContent className="w-full sm:max-w-2xl overflow-y-auto">
          {selectedCall && (
            <>
              <SheetHeader>
                <SheetTitle>Call Details</SheetTitle>
              </SheetHeader>

              <div className="mt-6 space-y-6">
                {/* Call Metadata */}
                <div className="space-y-3">
                  <div className="flex items-center gap-3">
                    <div className="h-12 w-12 bg-blue-100 rounded-full flex items-center justify-center">
                      <Phone className="h-6 w-6 text-blue-600" />
                    </div>
                    <div>
                      <p className="text-lg font-semibold">{selectedCall.callerNumber}</p>
                      <p className="text-sm text-gray-600">{selectedCall.date} at {selectedCall.time}</p>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4 p-4 bg-gray-50 rounded-lg">
                    <div>
                      <p className="text-sm text-gray-600">Duration</p>
                      <p className="font-medium">{selectedCall.duration}</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-600">Status</p>
                      <div className="mt-1">{getOutcomeBadge(selectedCall.outcome)}</div>
                    </div>
                  </div>
                </div>

                {/* Audio Player */}
                {selectedCall.hasRecording ? (
                  <div className="space-y-2">
                    <h3 className="font-medium flex items-center gap-2">
                      <Volume2 className="h-4 w-4" />
                      Recording
                    </h3>
                    <div className="p-4 bg-gray-50 rounded-lg">
                      <audio controls className="w-full">
                        <source src={selectedCall.recordingUrl} type="audio/mpeg" />
                        Your browser does not support the audio element.
                      </audio>
                    </div>
                  </div>
                ) : (
                  <div className="p-4 bg-gray-50 rounded-lg text-center text-gray-500">
                    Recording unavailable
                  </div>
                )}

                {/* Transcript */}
                {selectedCall.hasTranscript && selectedCall.transcript ? (
                  <div className="space-y-2">
                    <h3 className="font-medium flex items-center gap-2">
                      <FileText className="h-4 w-4" />
                      Transcript
                    </h3>
                    <div className="p-4 bg-gray-50 rounded-lg space-y-2">
                      {selectedCall.transcript.split('\n').map((line, i) => (
                        <p key={i} className="text-sm">
                          {line}
                        </p>
                      ))}
                    </div>
                  </div>
                ) : (
                  <div className="p-4 bg-gray-50 rounded-lg text-center text-gray-500">
                    Transcript unavailable
                  </div>
                )}
              </div>
            </>
          )}
        </SheetContent>
      </Sheet>
    </div>
  );
}
