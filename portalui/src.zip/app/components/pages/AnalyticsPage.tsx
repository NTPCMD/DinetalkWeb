import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { BarChart, Bar, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { mockStats } from '../../lib/mock-data';

export function AnalyticsPage() {
  const { thisWeek } = mockStats;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-semibold text-gray-900">Analytics</h1>
        <p className="text-gray-600 mt-1">Track call performance and trends</p>
      </div>

      {/* Calls Per Day */}
      <Card>
        <CardHeader>
          <CardTitle>Calls This Week</CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={thisWeek.callsPerDay}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="day" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Bar dataKey="answered" fill="#3b82f6" name="Answered" />
              <Bar dataKey="missed" fill="#ef4444" name="Missed" />
            </BarChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      {/* Peak Hours */}
      <Card>
        <CardHeader>
          <CardTitle>Peak Call Hours</CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={thisWeek.peakHours}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="hour" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Line type="monotone" dataKey="calls" stroke="#8b5cf6" strokeWidth={2} name="Calls" />
            </LineChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      {/* Summary Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardContent className="p-6">
            <p className="text-sm text-gray-600">Total Calls This Week</p>
            <p className="text-3xl font-semibold mt-2">
              {thisWeek.callsPerDay.reduce((sum, day) => sum + day.answered + day.missed, 0)}
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6">
            <p className="text-sm text-gray-600">Answer Rate</p>
            <p className="text-3xl font-semibold mt-2">
              {(() => {
                const total = thisWeek.callsPerDay.reduce((sum, day) => sum + day.answered + day.missed, 0);
                const answered = thisWeek.callsPerDay.reduce((sum, day) => sum + day.answered, 0);
                return `${Math.round((answered / total) * 100)}%`;
              })()}
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6">
            <p className="text-sm text-gray-600">Busiest Day</p>
            <p className="text-3xl font-semibold mt-2">
              {thisWeek.callsPerDay.reduce((max, day) => 
                (day.answered + day.missed) > (max.answered + max.missed) ? day : max
              ).day}
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
