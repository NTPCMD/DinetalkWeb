import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Label } from '../ui/label';
import { Switch } from '../ui/switch';
import { Badge } from '../ui/badge';
import { MessageSquare, CheckCircle } from 'lucide-react';
import { mockSMS } from '../../lib/mock-data';

export function SMSPage() {
  const [smsEnabled, setSmsEnabled] = useState(mockSMS.enabled);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-semibold text-gray-900">SMS</h1>
        <p className="text-gray-600 mt-1">Configure SMS confirmation messages</p>
      </div>

      {/* Toggle Card */}
      <Card>
        <CardHeader>
          <CardTitle>SMS Confirmations</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label htmlFor="sms-toggle" className="text-base">Enable SMS Confirmations</Label>
              <p className="text-sm text-gray-500">
                Send automated confirmation messages to customers
              </p>
            </div>
            <Switch
              id="sms-toggle"
              checked={smsEnabled}
              onCheckedChange={setSmsEnabled}
            />
          </div>

          {smsEnabled && (
            <div className="flex items-center gap-2 text-green-700 bg-green-50 p-3 rounded-md">
              <CheckCircle className="h-5 w-5" />
              <span>SMS confirmations are active</span>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Message Preview */}
      <Card>
        <CardHeader>
          <CardTitle>Message Preview</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="p-4 bg-gray-50 rounded-lg border border-gray-200">
            <div className="flex items-start gap-3">
              <MessageSquare className="h-5 w-5 text-blue-600 mt-0.5" />
              <div>
                <p className="text-sm text-gray-700 leading-relaxed">
                  {mockSMS.messageTemplate}
                </p>
                <p className="text-xs text-gray-500 mt-2">
                  Variables: {'{guests}'}, {'{date}'}, {'{time}'}
                </p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Usage Stats */}
      <Card>
        <CardHeader>
          <CardTitle>Usage Statistics</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="p-4 bg-blue-50 rounded-lg">
              <p className="text-sm text-blue-700">SMS Sent This Month</p>
              <p className="text-3xl font-semibold text-blue-900 mt-2">{mockSMS.sentThisMonth}</p>
            </div>
            <div className="p-4 bg-green-50 rounded-lg">
              <p className="text-sm text-green-700">Status</p>
              <div className="mt-2">
                <Badge variant={smsEnabled ? 'default' : 'secondary'}>
                  {smsEnabled ? 'Active' : 'Disabled'}
                </Badge>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
