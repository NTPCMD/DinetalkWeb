import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { Progress } from '../ui/progress';
import { CreditCard, Download } from 'lucide-react';
import { mockBilling } from '../../lib/mock-data';

export function BillingPage() {
  const minutesPercent = (mockBilling.usage.minutesUsed / mockBilling.usage.minutesIncluded) * 100;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-semibold text-gray-900">Billing</h1>
        <p className="text-gray-600 mt-1">Manage your subscription and view invoices</p>
      </div>

      {/* Current Plan */}
      <Card>
        <CardHeader>
          <CardTitle>Current Plan</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-2xl font-semibold">{mockBilling.currentPlan}</p>
              <p className="text-gray-600">${mockBilling.monthlyCost}/month</p>
            </div>
            <Button variant="outline">Upgrade Plan</Button>
          </div>
        </CardContent>
      </Card>

      {/* Usage Summary */}
      <Card>
        <CardHeader>
          <CardTitle>Usage This Month</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-2">
            <div className="flex items-center justify-between text-sm">
              <span className="text-gray-600">Minutes Used</span>
              <span className="font-medium">
                {mockBilling.usage.minutesUsed} / {mockBilling.usage.minutesIncluded}
              </span>
            </div>
            <Progress value={minutesPercent} />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="p-4 bg-blue-50 rounded-lg">
              <p className="text-sm text-blue-700">Calls Handled</p>
              <p className="text-3xl font-semibold text-blue-900 mt-2">
                {mockBilling.usage.callsHandled}
              </p>
            </div>
            <div className="p-4 bg-green-50 rounded-lg">
              <p className="text-sm text-green-700">Remaining Minutes</p>
              <p className="text-3xl font-semibold text-green-900 mt-2">
                {mockBilling.usage.minutesIncluded - mockBilling.usage.minutesUsed}
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Invoices */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle>Invoice History</CardTitle>
            <Button variant="ghost" size="sm">
              <Download className="h-4 w-4 mr-2" />
              Download All
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-1">
            {/* Table Header */}
            <div className="grid grid-cols-4 gap-4 pb-3 border-b font-medium text-sm text-gray-600">
              <div>Invoice ID</div>
              <div>Date</div>
              <div>Amount</div>
              <div>Status</div>
            </div>

            {/* Table Rows */}
            {mockBilling.invoices.map((invoice) => (
              <div key={invoice.id} className="grid grid-cols-4 gap-4 py-4 border-b last:border-0">
                <div className="flex items-center gap-2">
                  <CreditCard className="h-4 w-4 text-gray-400" />
                  <span className="font-medium">{invoice.id}</span>
                </div>
                <div className="flex items-center text-gray-700">{invoice.date}</div>
                <div className="flex items-center font-medium">${invoice.amount}</div>
                <div className="flex items-center">
                  <Badge variant={invoice.status === 'paid' ? 'default' : 'secondary'}>
                    {invoice.status}
                  </Badge>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Support */}
      <Card>
        <CardContent className="p-6">
          <div className="text-center">
            <p className="text-gray-600 mb-4">Need help with billing?</p>
            <Button variant="outline">Contact Support</Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
