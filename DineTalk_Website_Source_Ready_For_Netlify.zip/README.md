
  # DineTalk Website Layout

  This is a code bundle for DineTalk Website Layout. The original project is available at https://www.figma.com/design/wTBoAUJsLRI0hmzWp4Oggl/DineTalk-Website-Layout.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  